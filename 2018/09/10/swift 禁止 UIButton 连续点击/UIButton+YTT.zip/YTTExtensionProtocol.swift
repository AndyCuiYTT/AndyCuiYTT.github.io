//
//  YTTExtensionProtocol.swift
//  UIButtonTestDemo
//
//  Created by qiuweniOS on 2018/9/10.
//  Copyright © 2018年 AndyCuiYTT. All rights reserved.
//


/**
 * swift 利用 Runtime 交换方法相关.
 *
 *
 */

import Foundation

protocol YTTExtensionProtocol: class {
    static func awake()
}

class YTTExtensionManager {
    
    static func harmlessFunction() {
        
        let typeCount = Int(objc_getClassList(nil, 0))
        let types = UnsafeMutablePointer<AnyClass?>.allocate(capacity: typeCount)
        objc_getClassList(AutoreleasingUnsafeMutablePointer<AnyClass>(types), Int32(typeCount))
        for index in 0 ..< typeCount { (types[index] as? YTTExtensionProtocol.Type)?.awake() }
        types.deallocate()
    }
    
}





