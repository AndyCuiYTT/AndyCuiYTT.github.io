//
//  UIButton+YTT.swift
//  UIButtonTestDemo
//
//  Created by qiuweniOS on 2018/9/10.
//  Copyright © 2018年 AndyCuiYTT. All rights reserved.
//

import UIKit

private var UIButton_acceptEventTime: Void?
private var UIButton_acceptInterval: Void?

extension UIButton: YTTExtensionProtocol {
    
    static func awake() {
        if let oldMethod = class_getInstanceMethod(self, #selector(sendAction(_:to:for:))), let newMethod = class_getInstanceMethod(self, #selector(ytt_sendAction(_:to:for:))) {
            method_exchangeImplementations(oldMethod, newMethod)
        }
    }
    
    // 连续点击时间间隔
    var acceptEventInterval: TimeInterval {
        get {
            if let time = objc_getAssociatedObject(self, &UIButton_acceptInterval) as? TimeInterval {
                return time
            } else {
                objc_setAssociatedObject(self, &UIButton_acceptInterval, 1, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
                return 1
            }
        }
        set {
            objc_setAssociatedObject(self, &UIButton_acceptInterval, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
    
    // 上次点击时间
    private var acceptEventTime: TimeInterval {
        get {
            if let time = objc_getAssociatedObject(self, &UIButton_acceptEventTime) as? TimeInterval {
                return time
            } else {
                objc_setAssociatedObject(self, &UIButton_acceptEventTime, 0, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
                return 0
            }
        }
        set {
            objc_setAssociatedObject(self, &UIButton_acceptEventTime, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
    
    @objc func ytt_sendAction(_ action: Selector, to target: Any?, for event: UIEvent?) {
        
        if Date().timeIntervalSince1970 - self.acceptEventTime >= acceptEventInterval {
            self.ytt_sendAction(action, to: target, for: event)
            acceptEventTime = Date().timeIntervalSince1970
        }
    }
}
