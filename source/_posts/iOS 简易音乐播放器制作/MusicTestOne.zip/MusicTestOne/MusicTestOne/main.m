//
//  main.m
//  MusicTestOne
//
//  Created by  AndyCui on 15/11/16.
//  Copyright © 2015年 AndyCuiYTT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
