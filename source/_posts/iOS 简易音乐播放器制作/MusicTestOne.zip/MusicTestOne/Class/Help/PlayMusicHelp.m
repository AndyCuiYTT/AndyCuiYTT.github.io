//
//  PlayMusicHelp.m
//  MusicTestOne
//
//  Created by  AndyCui on 15/11/17.
//  Copyright © 2015年 AndyCuiYTT. All rights reserved.
//

#import "PlayMusicHelp.h"
#import <AVFoundation/AVFoundation.h>

@interface PlayMusicHelp ()
{
   // NSString *isPlayingUrl;
}

//系统播放器
@property (nonatomic , strong)AVPlayer *avPlayer;

@property (nonatomic , strong)NSTimer *timer;



@end


@implementation PlayMusicHelp

+ (instancetype)sharePlayMusicHelp{
    static PlayMusicHelp *playMusicHelp = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        playMusicHelp = [[PlayMusicHelp alloc]init];
    });
    
    return playMusicHelp;
}

//重写 init 方法
- (instancetype)init{
    if (self = [super init]) {
        _index = -1;
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playToEnd) name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
    }
    return self;
}

- (void)playToEnd{
    //确保 block 存在
    if (self.playToEndBlock) {
        //回调block
         self.playToEndBlock();
    }
}


//懒加载 创建 avPlayer
- (AVPlayer*)avPlayer{
    if (!_avPlayer){
        _avPlayer = [[AVPlayer alloc]init];
        _avPlayer.volume = 1.0f;
        _isPlay = NO;
        
    }
    return _avPlayer;
}


- (void)playMusicMP3URL:(NSString *)MP3URL{
    
    //安全判断
    if (!MP3URL) {
        return;
    }
    
//    if ([[NSUserDefaults standardUserDefaults] integerForKey:@"playStyle"] != 3) {
//        if ([MP3URL isEqualToString:isPlayingUrl] ) {
//            return;
//        }else {
//            isPlayingUrl = MP3URL;
//        }
//    }
//    
    
    
    
    
    
    if (self.avPlayer.currentItem) {
        //移除已有监听
        [self.avPlayer.currentItem removeObserver:self forKeyPath:@"status"];
    }
    
    //创建碟片
    AVPlayerItem *playItem = [AVPlayerItem playerItemWithURL:[NSURL URLWithString:MP3URL]];
    //监听碟片
    [playItem addObserver:self forKeyPath:@"status" options:NSKeyValueObservingOptionNew context:nil];
    //放入音乐播放器中
    [self.avPlayer replaceCurrentItemWithPlayerItem:playItem];
    
    
}


- (void)play{
    [self.avPlayer play];
    self.isPlay = YES;
    
    //每 0.1 秒调用方法
    //安全判断
    if (!self.timer){
        
        self.timer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(playTimer) userInfo:nil repeats:YES];
        
        //将定时器加入 runloop 中
        [[NSRunLoop mainRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
        [self.timer fire];
    }
}

- (void)playTimer{
    //计算当前播放了多少秒
    CGFloat timer = _avPlayer.currentTime.value / _avPlayer.currentTime.timescale;
    
    if (self.playTimerBlock){
        self.playTimerBlock(timer);
    }
}

- (void)pause{
    [self.avPlayer pause];
    self.isPlay = NO;
    
    //销毁定时器
    if(self.timer){
        [self.timer invalidate];
        self.timer = nil;
    }
}


- (void)seekToTimer:(CGFloat)timer{
    
    //封装优化
    [self pause];
    
    //CMTimeMakeWithSeconds(timer, self.avPlayer.currentTime.timescale)  某一时间 播放的进度
    
    
    
    //计算时间 timer * _sumTime
    [self.avPlayer seekToTime:CMTimeMakeWithSeconds(timer * _sumTime, self.avPlayer.currentTime.timescale) completionHandler:^(BOOL finished) {
        if(finished){
            [self play];
        }
    }];
}




//实现监听方法
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context{
    
    //监听传值,获取改变后的值
    AVPlayerItemStatus status = [change[@"new"] integerValue];
    switch (status) {
    
        case AVPlayerItemStatusReadyToPlay:
            
            //总播放的长度 除以 每一帧时间
            _sumTime = self.avPlayer.currentItem.duration.value / self.avPlayer.currentItem.duration.timescale;
            [self play];
            break;
    
        default:{
            NSLog(@"错误");
        }
            break;
    }
    
}

//重写 setVolume
- (void)setVolume:(CGFloat)volume{
    _avPlayer.volume = volume;
}

//重写 volume

- (CGFloat)volume{
    return _avPlayer.volume;
}





@end
