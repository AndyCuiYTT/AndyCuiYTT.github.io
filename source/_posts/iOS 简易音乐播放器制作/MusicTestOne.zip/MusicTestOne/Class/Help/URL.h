//
//  URL.h
//  MusicTestOne
//
//  Created by  AndyCui on 15/11/16.
//  Copyright © 2015年 AndyCuiYTT. All rights reserved.
//

#ifndef URL_h
#define URL_h

#define AG_MusicListURL @"http://project.lanou3g.com/teacher/UIAPI/MusicInfoList.plist" //音乐列表接口





#endif /* URL_h */
