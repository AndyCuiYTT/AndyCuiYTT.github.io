//
//  PlayMusicHelp.h
//  MusicTestOne
//
//  Created by  AndyCui on 15/11/17.
//  Copyright © 2015年 AndyCuiYTT. All rights reserved.
//

#import <Foundation/Foundation.h>

#define AG_SharePlayMusicHelp [PlayMusicHelp sharePlayMusicHelp]

@interface PlayMusicHelp : NSObject

//当前播放音乐的总时长
@property (nonatomic , assign)CGFloat sumTime;
//音量
@property (nonatomic , assign)CGFloat volume;

//是否播放
@property (nonatomic , assign)BOOL isPlay;

//播放完成回调
@property (nonatomic , copy)void(^playToEndBlock)();

//0.1 秒回调的 block
@property (nonatomic , copy)void(^playTimerBlock)(CGFloat timer);

@property (nonatomic , assign)NSInteger index;

//

+ (instancetype)sharePlayMusicHelp;


/**
 *  传入音乐地址
 *
 *  @param MP3URL MP3 的地址
 */
- (void)playMusicMP3URL:(NSString*)MP3URL;

/**
 *  播放
 */
- (void)play;


/**
 *  暂停
 */
- (void)pause;


/**
 *  某一时刻开始播放
 *
 *  @param timer 当前时间占总时间比例
 */
- (void)seekToTimer:(CGFloat)timer;


@end
