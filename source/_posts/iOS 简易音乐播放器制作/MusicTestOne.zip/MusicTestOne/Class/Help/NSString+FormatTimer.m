//
//  NSString+FormatTimer.m
//  MusicTestOne
//
//  Created by  AndyCui on 15/11/18.
//  Copyright © 2015年 AndyCuiYTT. All rights reserved.
//

#import "NSString+FormatTimer.h"

@implementation NSString (FormatTimer)

+ (NSString*)formatTimer:(CGFloat)timer{
    
    return  [NSString stringWithFormat:@"%02ld:%02ld",(NSInteger)timer/60,(NSInteger)timer%60];
    
}

- (CGFloat)AG_StringToTime{
    
    NSString *minute = [[self componentsSeparatedByString:@":"] firstObject];
    NSString *seconde = [[self componentsSeparatedByString:@":"] lastObject];
    
    //换算成秒
    CGFloat time = [minute floatValue] * 60 + [seconde floatValue];
    
    return time;
}

@end
