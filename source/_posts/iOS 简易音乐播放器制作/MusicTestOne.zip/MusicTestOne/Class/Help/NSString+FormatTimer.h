//
//  NSString+FormatTimer.h
//  MusicTestOne
//
//  Created by  AndyCui on 15/11/18.
//  Copyright © 2015年 AndyCuiYTT. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (FormatTimer)

+ (NSString*)formatTimer:(CGFloat)timer;

- (CGFloat)AG_StringToTime;


@end
