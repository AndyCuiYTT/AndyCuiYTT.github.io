//
//  RequestData.m
//  MusicTestOne
//
//  Created by  AndyCui on 15/11/16.
//  Copyright © 2015年 AndyCuiYTT. All rights reserved.
//

#import "RequestData.h"

@implementation RequestData

+ (void)requestDataURL:(NSString*)URLStr block:(void(^)(NSArray *array))requestBlock{
    
    //子线程请求数据
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        NSArray *array = [NSArray arrayWithContentsOfURL:[NSURL URLWithString:URLStr]];
        //创建储存 model 数组
        NSMutableArray *modelArray = [NSMutableArray array];
        for (NSDictionary *dic in array) {
            MusicModel *model = [[MusicModel alloc]init];
            [model setValuesForKeysWithDictionary:dic];
            [RequestData musicModelRequest:model];
            [modelArray addObject:model];
        }
        //主线程返回数据
        dispatch_async(dispatch_get_main_queue(), ^{
            if (requestBlock) {
                //回调
                requestBlock (modelArray);
            }
        });
    });
}
             
             
             
+ (void)musicModelRequest:(MusicModel *)model{
    NSString *str = model.lyric;
    //歌词和时间数组
    NSArray *arr = [str componentsSeparatedByString:@"\n"];
    //歌词时间数组
    NSMutableArray *timerMutableArray = [NSMutableArray array];
    //歌词数组
    NSMutableArray *lysicMutableArray = [NSMutableArray array];
    
    for (NSString *string in arr) {
        
        //拆分时间和歌词
        NSArray *timeAndLyric = [string componentsSeparatedByString:@"]"];
        //拆分时间
        NSArray *timerArray = [timeAndLyric.firstObject componentsSeparatedByString:@"["];
        //添加时间
        [timerMutableArray addObject:timerArray.lastObject];
        //添加歌词
        [lysicMutableArray addObject:timeAndLyric.lastObject];
    }
    
   
    //赋值
    model.timerArray = [NSArray arrayWithArray:timerMutableArray];
    model.lyricArray = [NSArray arrayWithArray:lysicMutableArray];
    
}


@end
