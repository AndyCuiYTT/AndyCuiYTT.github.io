//
//  MusicPlayerViewController.h
//  MusicTestOne
//
//  Created by  AndyCui on 15/11/17.
//  Copyright © 2015年 AndyCuiYTT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MusicPlayerViewController : UIViewController

@property (nonatomic , strong)NSArray *musicArray;//歌曲数组

@property (nonatomic , assign)NSInteger index;//歌曲下标


@property (weak, nonatomic) IBOutlet UIImageView *musicImageView;





@end
