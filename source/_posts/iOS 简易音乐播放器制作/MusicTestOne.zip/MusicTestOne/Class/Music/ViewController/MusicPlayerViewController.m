//
//  MusicPlayerViewController.m
//  MusicTestOne
//
//  Created by  AndyCui on 15/11/17.
//  Copyright © 2015年 AndyCuiYTT. All rights reserved.
//

#import "MusicPlayerViewController.h"
#import "LuricTableViewCell.h"
#import "NSString+FormatTimer.h"

@interface MusicPlayerViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    MusicModel *model;
}

@property (weak, nonatomic) IBOutlet UISlider *seekSlider;

@property (weak, nonatomic) IBOutlet UISlider *volumeSlider;

@property (weak, nonatomic) IBOutlet UITableView *lyricTableView;

@property (weak, nonatomic) IBOutlet UILabel *beginLabel;

@property (weak, nonatomic) IBOutlet UILabel *endLabel;

@property (weak, nonatomic) IBOutlet UIButton *pauseBtn;


@end

@implementation MusicPlayerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.lyricTableView.delegate = self;
    self.lyricTableView.dataSource = self;
    [self playMusic];
    
    //播放完成回调
    AG_SharePlayMusicHelp.playToEndBlock = ^(){
        
        NSInteger playStyle = [[NSUserDefaults standardUserDefaults] integerForKey:@"playStyle"];
        if (playStyle == 3) {
            model = self.musicArray[_index];
            [AG_SharePlayMusicHelp playMusicMP3URL:model.mp3Url];
        }else {
            [self downPlayMusic:nil];
        }
    };
    
    AG_SharePlayMusicHelp.playTimerBlock = ^(CGFloat timer){
        [self playTimer:timer];
    };
    
    [self setViews];
    
}

- (NSIndexPath*)lyricTableViewTime:(CGFloat)time{
    for (int i = 0 ; i < model.timerArray.count ; i++){
        CGFloat timeArray = [model.timerArray[i] AG_StringToTime];
        if (time < timeArray){
            return [NSIndexPath indexPathForItem:(i - 1 > 0 ? i - 1 : 0) inSection:0];
        }
    }
    return [NSIndexPath indexPathForItem:model.timerArray.count - 1 inSection:0];
}



- (void)playTimer:(CGFloat)timer{
    
    self.beginLabel.text = [NSString formatTimer:timer];
    
    self.endLabel.text = [NSString formatTimer:(AG_SharePlayMusicHelp.sumTime - timer)];
    
    self.seekSlider.value = timer / AG_SharePlayMusicHelp.sumTime;
    
    self.musicImageView.transform = CGAffineTransformRotate(self.musicImageView.transform, M_PI / 180);
    
//    NSArray *timeArray = model.timerArray;
//    
//    for (int i = 0 ; i < timeArray.count ; i++) {
//        
//        NSString *str = [[timeArray[i] componentsSeparatedByString:@"."] firstObject];
//        
//        if ([[NSString formatTimer:timer] isEqualToString:str]) {
//            [self.lyricTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0] animated:YES scrollPosition:UITableViewScrollPositionMiddle];
//        }
//    }
    
    [self.lyricTableView selectRowAtIndexPath:[self lyricTableViewTime:timer] animated:YES scrollPosition:UITableViewScrollPositionMiddle];
    
      
}


- (void)setViews{
    [self.musicImageView layoutIfNeeded];
    self.musicImageView.layer.masksToBounds = YES;
    self.musicImageView.layer.cornerRadius = self.musicImageView.frame.size.height / 2.0f;
    self.musicImageView.layer.borderColor = [[UIColor cyanColor] CGColor];
    self.musicImageView.layer.borderWidth = 3.0;
    
    [self.navigationItem.rightBarButtonItem setImage:[UIImage imageNamed:[NSString stringWithFormat:@"style_%ld",[[NSUserDefaults standardUserDefaults] integerForKey:@"playStyle"]]]];
    
    [self.volumeSlider layoutIfNeeded];
    self.volumeSlider.value = AG_SharePlayMusicHelp.volume;
}





- (void)playMusic{
    model = self.musicArray[_index];
    
    if (AG_SharePlayMusicHelp.index != _index) {
        [AG_SharePlayMusicHelp playMusicMP3URL:model.mp3Url];
        AG_SharePlayMusicHelp.index = _index;
    }
    
    
    
    
    self.navigationItem.title = model.name;
    
    [self.musicImageView sd_setImageWithURL:[NSURL URLWithString:model.picUrl]];
    
    UIImageView *imgeView = [[UIImageView alloc]initWithFrame:self.lyricTableView.frame];
    [imgeView sd_setImageWithURL:[NSURL URLWithString:model.picUrl]];
    
    self.lyricTableView.backgroundView = imgeView;
    
    
    
   
    [self.lyricTableView reloadData];
    self.lyricTableView.contentOffset = CGPointMake(0, 0);
    
}

#pragma mark --- 播放控制 ---

//随机播放时选中的歌曲 序号

- (NSInteger)randomIndex{
    return arc4random()%(self.musicArray.count);
}



//上一首
- (IBAction)upPlayMusic:(id)sender {
    
    NSInteger playStyle = [[NSUserDefaults standardUserDefaults] integerForKey:@"playStyle"];
    

    if (playStyle == 2) {
        _index = [self randomIndex];
    }else {
        _index = _index == 0 ? (self.musicArray.count - 1) : (--_index);
    }
    
    [self playMusic];
    [self.pauseBtn setImage:[UIImage imageNamed:@"Play"] forState:UIControlStateNormal];
}

//播放/暂停
- (IBAction)playToStopMusic:(id)sender {
    
    if (AG_SharePlayMusicHelp.isPlay) {
        
        [sender setImage:[UIImage imageNamed:@"Pause"] forState:UIControlStateNormal];
        [AG_SharePlayMusicHelp pause];
    }else {
        [sender setImage:[UIImage imageNamed:@"Play"] forState:UIControlStateNormal];
        [AG_SharePlayMusicHelp play];
    }
    
}






//下一首
- (IBAction)downPlayMusic:(id)sender {
    
    NSInteger playStyle = [[NSUserDefaults standardUserDefaults] integerForKey:@"playStyle"];
    
    if (playStyle == 2) {
        _index = [self randomIndex];
    }else {
        _index = _index == (self.musicArray.count - 1) ? 0 : (++_index);
    }

    [self playMusic];
    [self.pauseBtn setImage:[UIImage imageNamed:@"Play"] forState:UIControlStateNormal];
}

//滑竿
- (IBAction)seekValue:(UISlider *)sender {
    
    [AG_SharePlayMusicHelp seekToTimer:sender.value];
    
}


//音量
- (IBAction)volumePlay:(UISlider *)sender {
    AG_SharePlayMusicHelp.volume = sender.value;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return model.lyricArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    //storyBoard 不需要注册
    LuricTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"lyric_cell" forIndexPath:indexPath];
    
    UIView *view = [[UIView alloc]initWithFrame:cell.frame];
    view.backgroundColor = [UIColor cyanColor];
    
    cell.selectedBackgroundView = view;
   
    //cell.selectedBackgroundView.alpha = 0.5;
    
    cell.selectionStyle = UITableViewCellSelectionStyleBlue;
    
    cell.backgroundColor = [UIColor clearColor];

    //    cell.contentView.alpha = 0.5;
    //    cell.alpha = 0.5;
    
    cell.lyricLabel.text = model.lyricArray[indexPath.row];
    return cell;
}



//循环图标
- (IBAction)rightBarButtonAction:(id)sender {
    
    NSInteger playStyle = [[NSUserDefaults standardUserDefaults] integerForKey:@"playStyle"];
    
    switch (playStyle) {
        case 1:
            //1. 代表循序
            [self.navigationItem.rightBarButtonItem setImage:[UIImage imageNamed:@"style_2"]];
            [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"playStyle"];
            break;
            
        case 2:
            //2 . 代表随机
            [self.navigationItem.rightBarButtonItem setImage:[UIImage imageNamed:@"style_3"]];
            [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"playStyle"];
            break;
            
        case 3:
            //3. 代表单曲循环
            [self.navigationItem.rightBarButtonItem setImage:[UIImage imageNamed:@"style_1"]];
            [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"playStyle"];
            break;
            
        default:
            [self.navigationItem.rightBarButtonItem setImage:[UIImage imageNamed:@"style_1"]];
            [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"playStyle"];
            break;
    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
