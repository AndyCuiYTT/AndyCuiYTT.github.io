//
//  MusicModel.m
//  MusicTestOne
//
//  Created by  AndyCui on 15/11/16.
//  Copyright © 2015年 AndyCuiYTT. All rights reserved.
//

#import "MusicModel.h"

@implementation MusicModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    if ([key isEqualToString:@"id"]){
        _ID = (NSInteger)value;
    }
}



@end
