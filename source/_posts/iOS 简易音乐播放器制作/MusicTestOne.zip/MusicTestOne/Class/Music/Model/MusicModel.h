//
//  MusicModel.h
//  MusicTestOne
//
//  Created by  AndyCui on 15/11/16.
//  Copyright © 2015年 AndyCuiYTT. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MusicModel : NSObject

@property (nonatomic , strong)NSString *mp3Url;//播放地址
@property (nonatomic , strong)NSString *name;//歌曲名称
@property (nonatomic , strong)NSString *picUrl;//图片地址
@property (nonatomic , assign)NSInteger ID;
@property (nonatomic , strong)NSString *singer;


@property (nonatomic , strong)NSString *lyric;//歌词
@property (nonatomic , strong)NSArray *lyricArray;//储存歌词数组
@property (nonatomic , strong)NSArray *timerArray;//歌词对应事件数组



@end
