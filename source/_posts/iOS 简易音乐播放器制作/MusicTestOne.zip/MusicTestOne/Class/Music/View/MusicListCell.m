//
//  MusicListCell.m
//  MusicTestOne
//
//  Created by  AndyCui on 15/11/16.
//  Copyright © 2015年 AndyCuiYTT. All rights reserved.
//

#import "MusicListCell.h"

@implementation MusicListCell


- (void)setModel:(MusicModel *)model{
    if (model) {
        _model = model;
    }
    [self.musicImageView sd_setImageWithURL:[NSURL URLWithString:model.picUrl]];
    self.nameLabel.text = model.name;
    self.singerLabel.text = model.singer;
    self.musicImageView.layer.masksToBounds = YES;
    self.musicImageView.layer.cornerRadius = self.musicImageView.frame.size.height/2.0;
    [self.musicImageView layoutIfNeeded];
    /*
     storyBoard 托的视图走在viewdidLoad 之后,加上 [self.musicImageView layoutIfNeeded] 后,先在视图的约束,
     
     
     */
    
    
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
