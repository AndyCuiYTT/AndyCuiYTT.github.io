//
//  MusicListCell.h
//  MusicTestOne
//
//  Created by  AndyCui on 15/11/16.
//  Copyright © 2015年 AndyCuiYTT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MusicListCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

@property (weak, nonatomic) IBOutlet UIImageView *musicImageView;

@property (weak, nonatomic) IBOutlet UILabel *singerLabel;


@property (nonatomic , strong)MusicModel *model;


@end
