//
//  LuricTableViewCell.h
//  MusicTestOne
//
//  Created by  AndyCui on 15/11/17.
//  Copyright © 2015年 AndyCuiYTT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LuricTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lyricLabel;


@end
