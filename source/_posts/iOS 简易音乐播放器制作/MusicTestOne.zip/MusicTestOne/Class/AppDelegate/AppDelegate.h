//
//  AppDelegate.h
//  MusicTestOne
//
//  Created by AndyCui on 15/11/16.
//  Copyright © 2015年 AndyCuiYTT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

