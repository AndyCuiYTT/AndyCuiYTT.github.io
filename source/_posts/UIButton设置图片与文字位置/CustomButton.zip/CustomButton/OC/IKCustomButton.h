//
//  IKCustomButton.h
//  ink
//
//  Created by 苗爽 on 2018/6/10.
//  Copyright © 2018年 山东数印网络科技有限公司. All rights reserved.
//  自定义按钮

#import <UIKit/UIKit.h>
/**
 *  按钮中图片的位置
 */
typedef NS_ENUM(NSUInteger, IKImageAlignment) {
    /**
     *  图片在左，默认
     */
    IKImageAlignmentLeft = 0,
    /**
     *  图片在上
     */
    IKImageAlignmentTop,
    /**
     *  图片在下
     */
    IKImageAlignmentBottom,
    /**
     *  图片在右
     */
    IKImageAlignmentRight,
};

@interface IKCustomButton : UIButton
/**
 *  按钮中图片的位置
 */
@property(nonatomic,assign)IKImageAlignment imageAlignment;
/**
 *  按钮中图片与文字的间距
 */
@property(nonatomic,assign)CGFloat spaceBetweenTitleAndImage;
@end
