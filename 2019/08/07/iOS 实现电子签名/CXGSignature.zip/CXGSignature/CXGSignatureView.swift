//
//  CXGSignatureView.swift
//
//  Created by CuiXg on 2019/8/7.
//  Copyright © 2019 AndyCuiYTT. All rights reserved.
//

/**
 *  参考: https://github.com/xx040145/JPZSign
 */


import UIKit

class CXGSignatureView: UIView {
    
    lazy var signView: CXGSignView = {
        return CXGSignView(frame: CGRect(x: 0, y: 40, width: frame.width, height: frame.height - 40))
    }()
    
    var signFinish: ((UIImage?) -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        setupSubviews()
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func setupSubviews() {
        
        
        let btnWidth = (frame.width - 20) / 3
        
        // 撤销
        let undoBtn = UIButton(type: .custom)
        undoBtn.layer.borderWidth = 2
        undoBtn.layer.borderColor = UIColor.gray.withAlphaComponent(0.6).cgColor
        undoBtn.frame = CGRect(x: 5, y: 0, width: btnWidth, height: 40)
        undoBtn.setTitle("撤销", for: .normal)
        undoBtn.setTitleColor(UIColor.black, for: .normal)
        undoBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        self.addSubview(undoBtn)
        undoBtn.addTarget(self, action: #selector(undoSign), for: .touchUpInside)
        
        // 清空
        
        let cleanBtn = UIButton(type: .custom)
        cleanBtn.layer.borderWidth = 2
        cleanBtn.layer.borderColor = UIColor.gray.withAlphaComponent(0.6).cgColor
        cleanBtn.frame = CGRect(x: btnWidth + 10, y: 0, width: btnWidth, height: 40)
        cleanBtn.setTitle("重签", for: .normal)
        cleanBtn.setTitleColor(UIColor.black, for: .normal)
        cleanBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        self.addSubview(cleanBtn)
        cleanBtn.addTarget(self, action: #selector(cleanSign), for: .touchUpInside)

        // 完成
        
        let finishBtn = UIButton(type: .custom)
        finishBtn.layer.borderWidth = 2
        finishBtn.layer.borderColor = UIColor.gray.withAlphaComponent(0.6).cgColor
        finishBtn.frame = CGRect(x: btnWidth * 2 + 15, y: 0, width: btnWidth, height: 40)
        finishBtn.setTitle("完成", for: .normal)
        finishBtn.setTitleColor(UIColor.black, for: .normal)
        finishBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        self.addSubview(finishBtn)
        finishBtn.addTarget(self, action: #selector(finishSign), for: .touchUpInside)

        self.addSubview(signView)
        
    }
    
    @objc func undoSign() {
        signView.undoSign()
    }
    
    @objc func cleanSign() {
        signView.clearSign()
    }
    
    @objc func finishSign() {
        let image = signView.saveSignToImage()
        signFinish?(image)
    }
    
    
    
}

