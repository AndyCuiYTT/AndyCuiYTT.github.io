//
//  CXGDownloadTools.swift
//
//  Created by CuiXg on 2019/7/15.
//  Copyright © 2019 AndyCuiYTT. All rights reserved.
//

import UIKit
import Alamofire

/***
 *  文件下载功能
 *  基于 Alamofire 需要提前导入 Alamofire 库 pod 'Alamofire', '~> 4.7.3'
 *  断点下载
 */

class CXGDownloadTools {
    
    var request: DownloadRequest?
    
    /// 断点下载
    ///
    /// - Parameters:
    ///   - url: 下载地址
    ///   - parameters: 请求参数
    ///   - progress: 进度
    ///   - success: 下载成功返回 本地存储地址
    ///   - failed: 下载失败
    func download(_ url: String, parameters: [String: Any]?, progress: @escaping (Float) -> Void, success: @escaping (String?) -> Void, failed: @escaping (String) -> Void) {
        
        // 获取文件名称
        let fileName = (url as NSString).lastPathComponent
        
        // 获取文件保存路径
        guard let path = downloadPath(fileName) else {
            failed("获取文件路径失败")
            return
        }
        
        // 检测文件是否已经保存,已经保存返回保存地址
        if FileManager.default.fileExists(atPath: path) {
            success(path)
            return
        }
        
        //拼接文件保存地址
        let destination: DownloadRequest.DownloadFileDestination = { _, response in
            return (URL(fileURLWithPath: path), [.removePreviousFile, .createIntermediateDirectories])
        }
        
        // 判断是否存在下载记录信息,如果有继续下载,否则重新下载
        if let resumeData = downloadResumeData(path) {
            request = Alamofire.download(resumingWith: resumeData, to: destination).downloadProgress(closure: { (pro) in
                progress(Float(pro.completedUnitCount) / Float(pro.totalUnitCount))
            }).responseData(completionHandler: { (response) in
                response.result.withValue({ (result) in
                    // 下载成功,返回保存路径地址
                    success(response.destinationURL?.path)
                    let _ = self.deleteTempFile(path)
                }).withError({ (error) in
                    // 出现错误,保存下载信息
                    let _ = self.writeToTempFile(path, data: response.resumeData)
                    failed(error.localizedDescription)
                })
            })
        }else {
            request = Alamofire.download(url, method: .get, parameters: parameters, encoding: JSONEncoding.default, headers: [:], to: destination).downloadProgress(closure: { (pro) in
                progress(Float(pro.completedUnitCount) / Float(pro.totalUnitCount))
            }).responseData(completionHandler: { (response) in
                response.result.withValue({ (result) in
                    success(response.destinationURL?.path)
                    let _ = self.deleteTempFile(path)
                }).withError({ (error) in
                    // resumeData 不是已经下载数据,而是记录当前下载进度的数据
                    let _ = self.writeToTempFile(path, data: response.resumeData)
                    failed(error.localizedDescription)
                })
            })
        }
    }
    
    func cancel() {
        request?.cancel()
    }
    
    
    /// 下载文件保存路径 默认为 Library/Caches/downloadFiles/fileName
    ///
    /// - Parameter fileName: 文件名
    /// - Returns: 文件地址
    private func downloadPath(_ fileName: String) -> String? {
        guard var path = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true).first?.appending("/downloadFiles") else {
            return nil
        }
        if !FileManager.default.fileExists(atPath: path) {
            do {
                try FileManager.default.createDirectory(atPath: path, withIntermediateDirectories: true, attributes: nil)
            }catch {
                return nil
            }
        }
        path.append("/\(fileName)")
        return path
        
    }
    
    
    /// 获取下载记录信息
    ///
    /// - Parameter path: 下载文件全部路径
    /// - Returns: 下载记录消息
    private func downloadResumeData(_ path: String) -> Data? {
        let tempPath = path.appending(".temp")
        if FileManager.default.fileExists(atPath: tempPath) {
            return FileManager.default.contents(atPath: tempPath)
        }
        return nil
    }
    
    
    /// 将文件下载记录写入临时文件
    ///
    /// - Parameters:
    ///   - path: 文件下载保存路径,文件名加.temp 作为临时文件保存
    ///   - data: 下载记录数据
    /// - Returns: Bool
    private func writeToTempFile(_ path: String, data: Data?) -> Bool {
        
       let tempPath = path.appending(".temp")
        
        if FileManager.default.fileExists(atPath: tempPath) {
            do {
                try FileManager.default.removeItem(atPath: tempPath)
            }catch {
                print(error)
                return false
            }
        }
        FileManager.default.createFile(atPath: tempPath, contents: data, attributes: nil)
        return true
    }
    
    /// 删除临时文件,问价下载完成后,删除临时文件
    ///
    /// - Parameter path: 文件下载保存路径,文件名加.temp 作为临时文件保存
    /// - Returns: Bool
    private func deleteTempFile(_ path: String) -> Bool {
        
        let tempPath = path.appending(".temp")
        
        if FileManager.default.fileExists(atPath: tempPath) {
            do {
                try FileManager.default.removeItem(atPath: tempPath)
            }catch {
                print(error)
                return false
            }
        }
        return true
    }    
}
